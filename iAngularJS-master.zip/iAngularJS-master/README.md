# iAngularJS

本项目包含两大部分：

1. 除index.html之外的所有HTML页面，用来演示AngularJS各项功能的使用方法。
如：filter.html演示Fillter的使用，service.html演示Service的使用。

2. 以index.html为程序入口，演示在一个完整的CRUD项目中，如何综合运用AngularJS的各项功能。 

关于本项目的详细说明，请参考：[http://blog.csdn.net/hwhsong/article/details/54345868](http://blog.csdn.net/hwhsong/article/details/54345868)
