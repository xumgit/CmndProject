module.exports = {
  semi: false,
  jsxBracketSameLine: true,
  singleQuote: true
}
