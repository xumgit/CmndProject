import { Spin } from 'antd'
import * as React from 'react'
const Lading = () => (
  <div className="spin">
    <Spin size="large" />
  </div>
)

export default Lading
