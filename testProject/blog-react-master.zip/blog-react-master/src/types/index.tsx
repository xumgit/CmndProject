export interface IStoreState {
  article: object
}
export interface IPayload {
  pageIndex: number
  pageSize: number
  timeFile?: boolean
}
